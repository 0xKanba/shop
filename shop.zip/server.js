const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// Explicit route handlers for main pages to eliminate folder collision (e.g., /md) and double redirects
app.get(['/', '/index', '/index.html'], (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get(['/checkout', '/checkout.html'], (req, res) => {
  res.sendFile(path.join(__dirname, 'checkout.html'));
});

app.get(['/enter', '/enter.html'], (req, res) => {
  res.sendFile(path.join(__dirname, 'enter.html'));
});

app.get(['/product', '/product.html'], (req, res) => {
  res.sendFile(path.join(__dirname, 'product.html'));
});

app.get(['/md', '/md.html'], (req, res) => {
  res.sendFile(path.join(__dirname, 'md.html'));
});

// Serve static assets without trailing-slash redirects for folder names matching route names
app.use(express.static(__dirname, {
  extensions: ['html', 'htm'],
  redirect: false
}));

// Fallback to index.html for unrecognized routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});

